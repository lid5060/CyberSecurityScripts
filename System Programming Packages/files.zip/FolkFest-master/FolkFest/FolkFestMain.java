package org.hanarki;

import javax.swing.JFrame;



public class FolkFestMain
{
	public static void main (String[] args)
	{
		PaneFrame TabbedMainFrame = new PaneFrame();
		TabbedMainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		TabbedMainFrame.setSize(400,300);
		TabbedMainFrame.setVisible(true);
	}
}

		
